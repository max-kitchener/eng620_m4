/*
 * ****************************************************************************
 * File           :       main.c
 * Project        :       Real Time Embedded systems milestone 3
 *
 * Description    :       Simulates the user interface for the conveyor belt
 * ****************************************************************************
 * ChangeLog:
 */

// Standard C libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <unistd.h>
// Project filse
#include "config.h"
#include "cinterface.h"


//#define RAND_MAX 10

int shutdown = FALSE;
int debug = FALSE;

//Used for indicating which menu is active
enum
{
  TOP,
  COUNTERS,
  COUNTERS_CONV,
  RESET,
  RESET_CONV,
  SHUTDOWN,
  DEBUG
} menuLevel;

// Structure used to hold counter values for both conveyors
struct
{
  int big[2];
  int small[2];
  int collected[2];
} counters;

// User interface functions
void menu_printf(char menuArray[][UI_STRING_LENGTH], int numOptions);
void main_menu(int menuSelect);
void counter_menu(int ctr, int cnv);
void reset_menu(int ctr, int cnv);
int user_input(void);
void debug_printf(char *dbgMessage, ...);
int size_task(int side);
void count_task(int side);
void gate_task(int side);

// Conveyor belt simulation

void size_side_cnt(void);

/**
 * @brief main function for user interface simulation
 *
 */
void main(void)
{
  char string[20] = {0};
  int menuSelect;
  int counters;
  int conveyors;
  time_t t;

  //Initializes random number generator
  //Moved here as kept getting the same number generated
  srand((unsigned) time(&t));


  printf("Conveyor belt UI starting\n");


  //Default to top level menu
  menuLevel = TOP;

  while (shutdown == FALSE)
  {
    //state machine dependant on menu level
    switch (menuLevel)
    {
    //Top level of menu, should default to here
    case TOP:
      for (int i = 0; i < 10; i++)
      {
        int size;
        int side = LEFT;
        if(i % 2 == 0)
        {
          side = RIGHT;
        }

        size = size_task(side);

        if(size == 1)
        {
        count_task(side);
        }
        else if( size == 2)
        {
        gate_task(side);
        }
      }



      menu_printf(uiMainMenu, UI_MAIN_ITEMS);

      main_menu(user_input());
      break;

    //User has requested counter values
    case COUNTERS:
      menu_printf(uiCounterMenu, UI_MAIN_ITEMS);
      counters = user_input();
      printf("%d\n", counters);
      menuLevel = COUNTERS_CONV;
      break;

    //Decides which conveyor to print value for
    case COUNTERS_CONV:
      menu_printf(uiConveyorMenu, UI_MAIN_ITEMS);
      conveyors = user_input();
      printf("%d\n", conveyors);
      counter_menu(counters, conveyors);
      menuLevel = TOP;
      break;

    case RESET:
      menu_printf(uiCounterMenu, UI_MAIN_ITEMS);
      counters = user_input();
      menuLevel = RESET_CONV;
      break;

    case RESET_CONV:
      menu_printf(uiConveyorMenu, UI_MAIN_ITEMS);
      conveyors = user_input();
      reset_menu(counters, conveyors);
      menuLevel = TOP;
      break;

    case SHUTDOWN:
      printf("Shutting down\n");
      shutdown = TRUE;
      break;

    default:
      printf("Invalid input\n");
      menuLevel = TOP;
      break;
    }
  }
}


/**
 * @brief prints all options for the ui menu menuArray
 *
 * @param menuArray  pointer to array of strings for menu options
 * @param numOptions  number of options in menuArray
 */
void menu_printf(char menuArray[][UI_STRING_LENGTH], int numOptions)
{
  int menuItem;

  for (menuItem = 0; menuItem < numOptions; menuItem++)
  {
    printf("%s", menuArray[menuItem]);
  }
}

/**
 * @brief prints all options for the ui menu menuArray
 *
 * @param menuArray  pointer to array of strings for menu options
 * @param numOptions  number of options in menuArray
 */
void main_menu(int menuSelect)
{
  switch (menuSelect)
  {
  case 1:
    printf("Entering debug mode, press any key to exit\n");
    menuLevel = DEBUG;
    break;

  case 2:
    menuLevel = COUNTERS;
    break;

  case 3:
    menuLevel = RESET;
    break;

  case 4:
    menuLevel = SHUTDOWN;
    break;

  default:
    printf("Invalid input\n");
    menuLevel = TOP;
    break;
  }
}

/**
 * @brief prints all options for the ui menu menuArray
 *
 * @param menuArray  pointer to array of strings for menu options
 * @param numOptions  number of options in menuArray
 */
void counter_menu(int ctr, int cnv)
{
  int side;
  for ( side = 0; side < 2; side++)
  {
    if(cnv && (side+1))
    {
      printf("%s conveyor:\n", sideString[side]);
      if(ctr == SMALL || ctr == ALL)
      {
        printf("%d small blocks\n", counters.small[side]);
      }
      if(ctr == BIG || ctr == ALL)
      {
        printf("%d big blocks\n", counters.big[side]);
      }
      if(ctr == COLLECTED || ctr == ALL)
      {
        printf("%d blocks collected\n", counters.collected[side]);
      }
    }
  }
}


/**
 * @brief prints all options for the ui menu menuArray
 *
 * @param menuArray  pointer to array of strings for menu options
 * @param numOptions  number of options in menuArray
 */
void reset_menu(int ctr, int cnv)
{
  int side;
  for ( side = 0; side < 2; side++)
  {
    if(cnv && (side+1))
      {
      printf("%s conveyor:\n", sideString[side]);
      if(ctr == SMALL || ctr == ALL)
      {
        counters.small[side]=0;
        printf("Reset small count\n");
      }
      if(ctr == BIG || ctr == ALL)
      {
        counters.big[side]=0;
        printf("Reset big count\n");
      }
      if(ctr == COLLECTED || ctr == ALL)
      {
        counters.collected[side]=0;
        printf("Reset collected count\n");
      }
    }
  }
}


/**
 * @brief used to read user input from terminal
 *
 * @return int returns int value of user input
 */
int user_input(void)
{
  int len = 3;
  int val = 0;
  char str[len];

  // Get user input
  fgets(str, len, stdin);
  // Convert to int
  sscanf(str, "%d\n", &val);

  return val;
}

/**
 * @brief Same functionality as printf, but will only
 *        print when debugMode is TRUE
 *
 * @param dbgMessage string for printf message
 * @param ...        variable list of arguments fro dbgMessage
 */
void debug_printf(char *dbgMessage, ...)
{
  if (debug == TRUE)
  {
    va_list Args;
    va_start(Args, dbgMessage);

    vprintf(dbgMessage, Args);
  }
}


int size_task(int side)
{
  int sensorVal;
  int returnVal = 0;

  sensorVal = readSizeSensors(side);
  resetSizeSensors(side);
  if(sensorVal = 1)
  {
    counters.small[side]++;
    returnVal = 1;
  }
  else if(sensorVal = 3)
  {
    counters.big[side]++;
    returnVal = 2;
  }

}

void count_task(int side)
{
  int sensorVal;

  sensorVal = readCountSensor(side);
  readCountSensor(side);
  if(sensorVal = 1)
  {
    counters.collected[side]++;
  }
}

void gate_task(int side)
{
  int gateVal;
  if(side == LEFT)
  {
    gateVal = 1;
  }
  else if(side == RIGHT)
  {
    gateVal = 2;
  }

  setGates(gateVal);
  sleep(10);
  setGates(0);
}
